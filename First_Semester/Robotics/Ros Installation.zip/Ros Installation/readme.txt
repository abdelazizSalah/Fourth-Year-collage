Make the script executable by running this command in the terminal:
---->	chmod +x installation.sh

You can then execute the script by running this command in the terminal.
---->	./installation.sh
