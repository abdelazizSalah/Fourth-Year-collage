# TODOS
1. Apply accumlative ACK. 
2. Handle all error cases. 
3. Assume that there are no delays in the acknowledgements. 
4. on negative ack, we send the number of the last 